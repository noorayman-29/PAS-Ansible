#!/bin/sh

read x
echo $x
if [ -z "${x}" ]; then
   exit 1
else
   exit 0
fi
